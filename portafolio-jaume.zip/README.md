<div align="center">
<img width="120px"  src="https://raw.githubusercontent.com/no-te-rindas/logo/main/Logo/LeonidasEsteban-destello-envolvente-cuadrada.png" />
</div>

# Portafolio Jaume

¿Te gustaría mostrar crear tu portafolio profesional y conseguir el trabajo de tus sueños? Aquí encontrarás la manera correcta de hacerlo.

## Requerimientos

Agrega el menú hamburguesa y coloca el **mailto** para que puedan contactarse contigo.

- Dominio custom
- Mailto
- Accesibilidad como prioridad
- Sube tu código a GitHub
- Publica tu resultado
- Mándalo a revisión desde tu [perfil](https://leonidasesteban.com/estudiante)


## Desktop

<img width="400px"  src="https://raw.githubusercontent.com/uxcristopher/imagenes/main/Readmes/portafolio-jaume/jaume-desktop.png" />

## Mobile

<img width="200px" src="https://raw.githubusercontent.com/uxcristopher/imagenes/main/Readmes/portafolio-jaume/jaume-mobile.png" />

## Disclaimer

Todas son propuestas, el propósito de **/Proyectos** es brindarte el diseño, el límite de la creación lo dictan tus ganas de hacerlo realidad y tu skills del momento a la hora de codear.


## Créditos

Encuentra más proyectos asombrosos en [/Proyectos](https://leonidasesteban.com/proyectos)

Diseñado con ♥️ en leonidasesteban.com
